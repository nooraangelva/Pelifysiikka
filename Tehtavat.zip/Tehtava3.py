from vpython import *
#GlowScript 3.0 VPython 
#Sovellus perustuu seuraaviin tietoihin:
#Sun, massa 2.0e+30 kg , Mercury,R=57900Mm, v=47.362 km/s, Venus, R=108208 Mm, v=35.02 km/s, 
#Earth,R=1496000Mm, v=29.78 km/s , Mars, M=6,R=227920Mm, v=24,1 km/s

scene.width=700
scene.height=550
scene.range=2.5e+11  #nayttamon koolla on aurinkokunnan mittasuhteet
scene.forward=vec(0,1,-0.7)
scene.title='Inner Planets.  Aloita klikkaamalla'

M = 2.0e+30        # Sun mass kg
G = 6.67e-11       # Gravitaatiovakio

#Sijoitetaan planeetat oikeille etaisyyksilleen, mutta eri puolille aurinkoa
#ja annetaan niille todelliset nopeudet

sun = sphere(pos=vec(0,0,0),radius=11e+9,color=color.yellow,emissive=True)
earth = sphere(pos=vec(149.6e+9,0,0),radius=5.1e+9, texture=textures.earth,make_trail=True)
merc = sphere(pos=vec(57.9e+9*cos(1),57.9e+9*sin(1),0),radius=3.1e+9,color=vec(1,0.8,0),make_trail=True)
venus = sphere(pos=vec(108.2e+9*cos(3),108.2e+9*sin(3),0),radius=7e+9,color=vec(0.8,0.4,0),make_trail=True)
mars = sphere(pos=vec(227.9e+9*cos(5),227.9e+9*sin(5),0),radius=4.1e+9,color=color.red,make_trail=True)

earth.velocity = vec(0,29780,0)                    #Maan ratanopeus Wikipedian mukaan
merc.velocity = vec(-47362*sin(1),47362*cos(1),0)  #Merkuriuksen ratanopeus
venus.velocity = vec(-35020*sin(3),35020*cos(3),0) #Venuksen ratanopeus
mars.velocity = vec(-24100*sin(5),24100*cos(5),0)  #Marsin ratanopeus

#Planeettojen mukana kulkevat nimikyltit
labelmerc=label(pos=merc.pos,text='Mercury',yoffset=12,box=False)
labelvenus=label(pos=venus.pos,text='Venus',yoffset=12,box=False)
labelearth=label(pos=earth.pos,text='Earth',yoffset=12,box=False)
labelmars=label(pos=mars.pos,text='Mars',yoffset=12,box=False)
dt = 3600           # update interval = 1 hour

aikanaytto=label(pos=vec(0,0.9e+12,0),box=False,text='')  #alussa teksti on tyhja string

t = 0               # nollataan aikalaskuri
days=0              # nollataan paivalaskuri
years = 0           # nollataan vuosilaskuri

scene.pause()

while True:     #ns. ikuinen silmukka, toimii kunnes suljet sovelluksen
    rate(300)
 
    dMaa=earth.pos-sun.pos                              # lasketaan vektori auringosta maahan
    earth.acc= -G*M/mag2(dMaa)*hat(dMaa)        # lasketaan maan kiihtyvyys gravitaatiolaista
    earth.pos+=earth.velocity*dt+0.5*earth.acc*dt**2    # paivita maan paikka
    earth.velocity+=earth.acc*dt                        # paivita maan nopeus
    labelearth.pos=earth.pos            # kyltin paikka siirtyy kappaleen mukana
    
    dMerkurius=merc.pos-sun.pos                          
    merc.acc=-G*M/mag2(dMerkurius)*hat(dMerkurius)     
    merc.pos+=merc.velocity*dt+0.5*merc.acc*dt**2 
    merc.velocity+=merc.acc*dt 
    labelmerc.pos=merc.pos
    
    dVenus=venus.pos-sun.pos                          
    venus.acc=-G*M/mag2(dVenus)*hat(dVenus)         
    venus.pos+=venus.velocity*dt+0.5*venus.acc*dt**2 
    venus.velocity+=venus.acc*dt 
    labelvenus.pos=venus.pos
    
    dMars=mars.pos-sun.pos                          
    mars.acc=-G*M/mag2(dMars)*hat(dMars)         
    mars.pos+=mars.velocity*dt+0.5*mars.acc*dt**2 
    mars.velocity+=mars.acc*dt 
    labelmars.pos=mars.pos
    
    t += dt
    
    years=floor(t/(365*24*60*60))
    days = floor(t/(24*60*60)-years*365)
    aikanaytto.text = years+" vuotta "+days+" vrk "+floor(sqrt(earth.velocity.y**2+earth.velocity.x**2))+" speed"
# paivita aika
# paivita kylttien paikat
# paivita naytto, muoto on  
# vuodet lasketaan seuraavasti:  


