from vpython import *
#GlowScript 3.0 VPython
scene.width=800
scene.height=550
scene.background=0.2*color.blue
scene.opacity=0.2
scene.center=vec(0,5,0)
scene.forward=vec(0,-0.2,-1)
scene.range=22
scene.title='Vierimisanimaatio. Aloita klikkaamalla'

maa = box(pos=vec(0,-2.5,0),size=vec(80,1,30))
seina=box(pos=vec(23,6,0),size=vec(2,16,30),texture=textures.rock)
g=9.8                               # painovoiman kiihtyvyys
u=0.01                              #kitkakerroin

rulla=cylinder(pos=vec(-19,0,5),radius=2, axis=vec(0,0,-10),texture=textures.wood)
rulla.velocity=vec(10,0,0)
rulla.acc=-u*g*hat(rulla.velocity)   # kitkasta johtuva hidastuvuus

rulla.w=mag(rulla.velocity)/rulla.radius  #pallon kulmanopeus vierimisessa
akseli=rulla.axis         # rotaatioakseli alussa sama kuin sylinterin akseli

dt=0.01
OikeaReuna=20           #rullan kaantymispiste sen koskettaessa seinaa
scene.pause()           #odottaa hiiren klikkausta
scene.title='Rulla vierii seinaan ja takaisin. Kitka pysayttaa rullan'


while rulla.pos.x>-25:
    rate(100)
    rulla.pos+=rulla.velocity*dt
    rulla.acc=-u*g*hat(rulla.velocity)
    rulla.rotate(axis=akseli,angle=rulla.w*dt,origin=rulla.pos)
    rulla.velocity+=0.5*rulla.acc*dt
    rulla.w=mag(rulla.velocity)/rulla.radius
    
    if rulla.pos.x>20:
        akseli=vec(0,0,10)
        rulla.velocity.x=-rulla.velocity.x
        rulla.rotate(axis=akseli,angle=rulla.w*dt,origin=rulla.pos)
