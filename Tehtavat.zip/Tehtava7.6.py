from vpython import *
#GlowScript 3.0 VPython
# Tehtava 6 : digitaalinen ja analoginen kello
scene.range=10
scene.center=vec(0,2,0)
scene.title='KELLOTAULU'
taulu1=label(pos=vec(8,8,0),height=16,text='',box=False,color=color.yellow)
# LUODAAN KELLOTAULU 
taulu=cylinder(pos=vec(0,0,-0.2),radius=6, axis=vec(0,0,0.1),color=0.5*color.white)
kehys=ring(pos=vec(0,0,-0.2), radius=6, thickness=0.5, color=0.3*color.red,axis=vec(0,0,1))
napa=cylinder(pos=vec(0,0,0), radius=0.4,axis=vec(0,0,0.5),color=0.3*color.red)

klo3=cylinder(pos=vec(5,0,0), radius=0.2,axis=vec(0,0,0.5),color=0.3*color.red)
klo6=cylinder(pos=vec(0,-5,0), radius=0.2,axis=vec(0,0,0.5),color=0.3*color.red)
klo9=cylinder(pos=vec(-5,0,0), radius=0.2,axis=vec(0,0,0.5),color=0.3*color.red)
klo3=cylinder(pos=vec(0,5,0), radius=0.2,axis=vec(0,0,0.5),color=0.3*color.red)

# LUODAAN KELLOTAULUN VIISARIT  
tun=arrow(pos=vec(0,0,0.1), axis=vec(0,4,0),color=color.red,shaftwidth=0.4)
minut=arrow(pos=vec(0,0,0.3), axis=vec(0,5,0),color=color.blue,shaftwidth=0.2)
sek= arrow(pos=vec(0,0,0.5), axis=vec(0,6,0), color=color.white,shaftwidth=0.1)

# VIISAREIDEN KULMANOPEUDET
wtun= -(2*pi/86400)
wmin= -(2*pi/3600)   
wsek= -(2*pi/60) 
tunkulma = radians(90)
minkulma = radians(90)
sekkulma = radians(90)
dt=0.01
t = 0
while True:
    rate(100)    #testausvaiheessa nopeutetaan kelloa, lopuksi voidaan asettaa rate(100)
    tunkulma+=wtun*dt
    tun.axis=vec(5*cos(tunkulma),5*sin(tunkulma),0)
    minkulma+=wmin*dt
    minut.axis=vec(5*cos(minkulma),5*sin(minkulma),0)
    sekkulma+=wsek*dt
    sek.axis=vec(5*cos(sekkulma),5*sin(sekkulma),0)
    t+=dt
    hours = floor((t/3600))
    minutes = floor(t / 60)-60*hours
    seconds = floor(t-minutes*60-hours*3600)
    taulu1.text = hours+':'+minutes+':'+seconds
   