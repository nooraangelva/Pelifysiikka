from vpython import *
#GlowScript 3.0 VPython
scene.width=800
scene.height=650
scene.range=120
scene.center=vec(0,30,0)
scene.title='PALLO TULEE ALAS KOURUA, aloitus= click'


pallo=sphere(pos=vec(0,40,-80),radius=4,color=vec(4,7.5,0.1))

lattia=box(pos=vec(0,-0.5,0),size=vec(1,66,180),color=0.5*color.white,axis=vec(0,1,0))
taso1=box(pos=vec(-50,18,0),size=vec(1,50,180),color=0.5*color.white,axis=vec(1,1,0))
taso2=box(pos=vec(50,18,0),size=vec(1,50,180),color=0.5*color.white,axis=vec(-1,1,0))


pallo.velocity=vec(-17,15,4)  #pallon alkunopeus on nolla
a=vec(0,-9.81,0)
e=0.82     #tormayksen elastisuus
dt=0.01
 

scene.pause()

while pallo.pos.z<90:
    rate(300)
    pallo.pos+=pallo.velocity*dt+0.5*a*dt**2
    pallo.velocity+=a*dt
    n1=taso1.axis
    n2=taso2.axis
    
    if comp((pallo.pos-taso1.pos),n1)<pallo.radius+0.5*taso1.length and comp(pallo.velocity,n1)<0:
        pallo.velocity=pallo.velocity-(1+e)*proj(pallo.velocity,n1)
        
    if comp((pallo.pos-taso2.pos),n2)<pallo.radius+0.5*taso2.length and comp(pallo.velocity,n2)<0:
        pallo.velocity=pallo.velocity-(1+e)*proj(pallo.velocity,n2)
    #tormays lattian kanssa
    if (pallo.pos.y<=pallo.radius) and (pallo.velocity.y<0):
        pallo.velocity.y=-pallo.velocity.y*e

# TAYDENNA SILMUKAN KOODIA SITEN ETTA SE TOTEUTTAA
# PALLON PUTOAMISLIIKKEEN, SEKA TORMAYKSET LATTIAAN
# SEKA KOURUN MOLEMPIIN SEINÄMIIN 